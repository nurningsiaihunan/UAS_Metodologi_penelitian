
package uas_metodologi_penelitian;

import java.util.Scanner;

/**
 *
 * @author Nur Ningsi Aihunan
 */
public class UAS_Metodologi_Penelitian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Kasir_Tata().show();
         Scanner keyboard = new Scanner(System.in);
    }
    
}
