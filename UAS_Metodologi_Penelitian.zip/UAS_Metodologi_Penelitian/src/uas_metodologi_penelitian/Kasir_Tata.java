
package uas_metodologi_penelitian;

import java.util.Date;

/**
 *
 * @author Nur Ningsi Aihunan
 */
public class Kasir_Tata extends javax.swing.JFrame {

    /**
     * Creates new form Kasir_Tata
     */
    public Kasir_Tata() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        harga_satuan = new javax.swing.JTextField();
        nama_barang = new javax.swing.JComboBox<>();
        jumlah_barang = new javax.swing.JTextField();
        uang_bayar = new javax.swing.JTextField();
        kembalian = new javax.swing.JTextField();
        hitung = new javax.swing.JButton();
        bayar = new javax.swing.JButton();
        batal = new javax.swing.JButton();
        keluar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        area = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        total_belanjaan = new javax.swing.JTextField();
        struk = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Bodoni Bd BT", 1, 24)); // NOI18N
        jLabel1.setText("APLIKASI KASIR SEDERHANA");

        jLabel2.setFont(new java.awt.Font("Bodoni Bk BT", 0, 18)); // NOI18N
        jLabel2.setText("Nama Barang");

        jLabel3.setFont(new java.awt.Font("Bodoni Bk BT", 0, 18)); // NOI18N
        jLabel3.setText("Harga Satuan");

        jLabel4.setFont(new java.awt.Font("Bodoni Bk BT", 0, 18)); // NOI18N
        jLabel4.setText("Jumlah Barang");

        jLabel5.setFont(new java.awt.Font("Bodoni Bk BT", 0, 18)); // NOI18N
        jLabel5.setText("Uang Bayar");

        jLabel6.setFont(new java.awt.Font("Bodoni Bk BT", 0, 18)); // NOI18N
        jLabel6.setText("Kembalian");

        harga_satuan.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        harga_satuan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                harga_satuanActionPerformed(evt);
            }
        });

        nama_barang.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        nama_barang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1. Photocard", "2. Lightstick", "3. Album", "4. Postcards", "5. Gantung Kunci", "6. Wearables", "7. Tumbler", "8. Poster", "9. Kipas", "10. Mug" }));
        nama_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nama_barangActionPerformed(evt);
            }
        });

        jumlah_barang.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        jumlah_barang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jumlah_barangActionPerformed(evt);
            }
        });

        uang_bayar.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        uang_bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uang_bayarActionPerformed(evt);
            }
        });

        kembalian.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        kembalian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kembalianActionPerformed(evt);
            }
        });

        hitung.setBackground(new java.awt.Color(250, 250, 250));
        hitung.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        hitung.setText("Hitung");
        hitung.setPreferredSize(new java.awt.Dimension(72, 30));
        hitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hitungActionPerformed(evt);
            }
        });

        bayar.setBackground(new java.awt.Color(250, 250, 250));
        bayar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        bayar.setText("Bayar");
        bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bayarActionPerformed(evt);
            }
        });

        batal.setBackground(new java.awt.Color(250, 250, 250));
        batal.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        batal.setText("Batal");
        batal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                batalActionPerformed(evt);
            }
        });

        keluar.setBackground(new java.awt.Color(250, 250, 250));
        keluar.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        keluar.setText("Keluar");
        keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keluarActionPerformed(evt);
            }
        });

        area.setColumns(20);
        area.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N
        area.setRows(5);
        jScrollPane1.setViewportView(area);

        jLabel7.setFont(new java.awt.Font("Bodoni Bk BT", 0, 18)); // NOI18N
        jLabel7.setText("Total Belanjaan");

        total_belanjaan.setFont(new java.awt.Font("Book Antiqua", 0, 12)); // NOI18N
        total_belanjaan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total_belanjaanActionPerformed(evt);
            }
        });

        struk.setBackground(new java.awt.Color(250, 250, 250));
        struk.setFont(new java.awt.Font("Bodoni MT", 1, 18)); // NOI18N
        struk.setText("Struk Belanja");
        struk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                strukActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Bodoni Bk BT", 1, 18)); // NOI18N
        jLabel8.setText("Pembayaran");

        jLabel9.setFont(new java.awt.Font("Bodoni Bk BT", 1, 18)); // NOI18N
        jLabel9.setText("Masukkan Belanjaan");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(104, 104, 104))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(104, 104, 104)
                            .addComponent(jLabel8))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel7)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel4))
                                    .addGap(30, 30, 30)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(harga_satuan, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jumlah_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(1, 1, 1)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(uang_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addComponent(total_belanjaan, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(nama_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jLabel6))
                            .addGap(11, 11, 11)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(batal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bayar, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                                .addComponent(hitung, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(170, 170, 170))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(201, 201, 201)
                                .addComponent(struk))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(226, 226, 226)
                                .addComponent(keluar)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(304, 304, 304)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(struk)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(140, 221, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(uang_bayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(17, 17, 17)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(kembalian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jScrollPane1)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(bayar)
                                    .addComponent(keluar))))
                        .addGap(27, 27, 27))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(nama_barang, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(hitung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(harga_satuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(jumlah_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(batal)
                            .addComponent(total_belanjaan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jumlah_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jumlah_barangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jumlah_barangActionPerformed

    private void uang_bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uang_bayarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uang_bayarActionPerformed

    private void hitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hitungActionPerformed
        int JumlahBarang=Integer.parseInt(jumlah_barang.getText());
        int HargaSatuan=Integer.parseInt(harga_satuan.getText());
        total_belanjaan.setText(Integer.toString(HargaSatuan*JumlahBarang));
        
    }//GEN-LAST:event_hitungActionPerformed

    private void total_belanjaanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total_belanjaanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_total_belanjaanActionPerformed

    private void bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bayarActionPerformed
        int UangBayar=Integer.parseInt(uang_bayar.getText());
        int TotalBelanjaan=Integer.parseInt(total_belanjaan.getText());
        if (UangBayar>=TotalBelanjaan){
            kembalian.setText(Integer.toString(UangBayar-TotalBelanjaan));
    }
        else{
        kembalian.setText("Uang Anda Kurang!");
    }
        
    }//GEN-LAST:event_bayarActionPerformed

    private void batalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_batalActionPerformed
        harga_satuan.setText("");
        jumlah_barang.setText("");
        total_belanjaan.setText("");
        uang_bayar.setText("");
        kembalian.setText("");
        nama_barang.setSelectedIndex(0);
    }//GEN-LAST:event_batalActionPerformed

    private void keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keluarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_keluarActionPerformed

    private void nama_barangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nama_barangActionPerformed
        String NamaBarang=(String)nama_barang.getSelectedItem();
        switch (NamaBarang){
            case "Photocard" -> { 
            }
            case "lightstick" -> {
            }
            case "Album" -> {
            }
            case "Postcards" -> {
            }
            case "Gantung Kunci" -> {
            }
            case "Wearables" -> {
            }
            case "Tumbler" -> {
            }
            case "Poster" -> {
            }
            case "Kipas" -> {
            }
            case "Mug" -> {
            }
    }//GEN-LAST:event_nama_barangActionPerformed
    }
    
    private void kembalianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kembalianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_kembalianActionPerformed

    private void strukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_strukActionPerformed
        area.setText("**********************************************************\n");
        area.setText(area.getText()+" *                    Struk Belanja                    *\n");
        area.setText(area.getText()+"**********************************************************\n");
        
        Date obj = new Date();
        
        String date = obj.toString();
        
        area.setText(area.getText()+" "+date+"\n");
        area.setText(area.getText()+" Nama Barang     : "+nama_barang.getSelectedItem()+"\n");
        area.setText(area.getText()+" Harga Satuan    : Rp."+harga_satuan.getText()+"\n");
        area.setText(area.getText()+" Jumlah Barang   : "+jumlah_barang.getText()+"\n\n");
        area.setText(area.getText()+" Total Belanjaan : Rp."+total_belanjaan.getText()+"\n");
        area.setText(area.getText()+" Uang Bayar      : Rp."+uang_bayar.getText()+"\n");
        area.setText(area.getText()+" Kembalian       : Rp."+kembalian.getText()+"\n");
        area.setText(area.getText()+"\n Barang yang telah dibeli tidak dapat ditukar/dikembalikan");
        area.setText(area.getText()+"\n");
        area.setText(area.getText()+" *           Terima Kasih Atas Kunjungan Anda           *\n");
        
        
    }//GEN-LAST:event_strukActionPerformed

    private void harga_satuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_harga_satuanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_harga_satuanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Kasir_Tata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Kasir_Tata().setVisible(true);
                new Kasir_Tata().show();

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea area;
    private javax.swing.JButton batal;
    private javax.swing.JButton bayar;
    private javax.swing.JTextField harga_satuan;
    private javax.swing.JButton hitung;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jumlah_barang;
    private javax.swing.JButton keluar;
    private javax.swing.JTextField kembalian;
    private javax.swing.JComboBox<String> nama_barang;
    private javax.swing.JButton struk;
    private javax.swing.JTextField total_belanjaan;
    private javax.swing.JTextField uang_bayar;
    // End of variables declaration//GEN-END:variables
}
